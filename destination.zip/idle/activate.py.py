import os
import menu
from tasks import Tasks
from tasksmanager import TasksManager

from start import main

main()
if __name__ == "__main__":
    main()