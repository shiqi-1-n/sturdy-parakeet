from tasks import Tasks
class Tasks:
    def __init__(self,id,title,description,deadline,priority,status):    #初始化类的属性(标题、描述、截止日期、优先级、状态)
        self.id=id
        self.title=title
        self.description=description
        self.deadline=deadline
        self.priority=priority
        self.status=status
    #创建Tasks类

    def update(self, title=None, description=None, deadline=None, priority=None, status=None):
        # 更新属性，先使各个参数恢复到默认值None
        if title:
            self.title = title
        if description:
            self.description = description
        if deadline:
            self.due_date = deadline
        if priority:
            self.priority = priority
        if status:
            self.status = status

        # 实现文档的更新
        # if语句：条件检查，如果有新的值，则将此新的值赋予到对应属性中
    def __str__(self):
        return f'{self.id}—{self.title}:{self.description}|截止日期:{self.deadline}|优先级:{self.priority}|完成状态:{self.status}'
#定义对象的字符串表示，提高代码的可读性和可维护性
class TasksManager:
 def __init__(self):
     self.tasks=[]
 #创建TasksManager类
 def add_task(self,id,title,description,deadline,priority,status):
     task=Tasks(id,title,description,deadline,priority,status)
     self.tasks.append(task)
     print("任务已创建完毕！")
 #添加新文件
 def delete_task(self,id):
     new_tasks=[]
     for task in self.tasks:
         if task.id!=id:
             new_tasks.append(task)
     self.tasks=new_tasks
 #通过输入id选择要删除的文件

 def update_task(self,id,**kwargs):
     for task in self.tasks:
         if task.id==id:
           task.update(**kwargs)
           break
 #通过输入id选择要更改属性的文件
 #**kwargs:可变长度的关键字参数，允许传递任意数量的命名参数
 def show_tasks(self,sort_by=None):
     if sort_by=='priority':
      tasks_to_show=sorted(self.tasks,key=lambda x:(x.priority))
     else:
      tasks_to_show = sorted(self.tasks, key=lambda x: (x.deadline))
     for task in tasks_to_show:
         print(task)
 #显示文件
 #x:self.tasks列表中的每一个任务对象
 #sorted:按一定规则(key)进行排序
 def save_tasks(self,filename):
     with open(filename,"w") as file:
         for task in self.tasks:
             file.write(f'{task.id},{task.title},{task.description},{task.deadline},{task.priority},{task.status}'+'\n')
 #保存文件
 #with open(...,"w")打开文件并写入内容
 def load_tasks(self,filename):
     loaded_tasks=[]
     try:
         with open(filename,'r') as file:
             for line in file:
                 id,title,description,deadline,priority,*status = line.strip().split(',')
                 task=Tasks(id,title,description,deadline,priority,status)
                 loaded_tasks.append(task)
     except FileNotFoundError:
         print("文件没有找到，初始化空任务列表")
 #下载文件
 #with open(..."r")打开文件并读取内容